﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPS
{
    class CError
    {
        private string message;
        private int line;

        public CError(string msg, int lineError)
        {
            message = msg;
            line = lineError;
        }

        public string setMessage { set { message = value; } }
        public string getMessage { get { return message; } }
        public int setLineNumber { set { line = value; } }
        public int getLineNumber { get { return line; } }
    }
}
