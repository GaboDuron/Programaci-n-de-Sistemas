﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPS
{
    class CSimbolo
    {
        private String name;
        private String address;

        public CSimbolo(String tag)
        {
            name = tag;
            address = "-1";
        }

        public string GetName{ get { return name; }
        }

        public string GetAddress { get { return address; } }

        public string SetName { set { name = value; } }

        public string SetAddress { set { address = value; } }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            CSimbolo sim = obj as CSimbolo;
            if (sim == null) return false;
            else return Equals(sim);
        }

        public bool Equals(CSimbolo sim)
        {
            if (sim == null) return false;
            return (this.name.Equals(sim.name));
        }

    }
}
