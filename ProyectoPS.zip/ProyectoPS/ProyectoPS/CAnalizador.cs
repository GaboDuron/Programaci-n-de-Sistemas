﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProyectoPS
{
    class CAnalizador
    {
        private bool bandInicio;             //Bandera que verifica la existencia de START
        private bool bandFinal;              //Bandera que verifica la existencia de END
        private int Nerror;                 //Contador de errores
        private static String nameArch;        //Nombre del archivo a analizar
        private List<CSimbolo> TABSIM;                     //TABSIM 
        public List<string> errores;           //Lista de errores
        private string[] programLines;

        public CAnalizador(string[] text)
        {
            bandInicio = bandFinal = false;
            Nerror = 0;
            nameArch = "test";
            TABSIM = new List<CSimbolo>();
            errores = new List<string>();
            programLines = text;
        }

        /*Funcion:
                Inicia el analisis lexico y sintactico*/
        public int validaSintaxis()
        {
            string line;
            char[] separadores = { ' ', '\t', '\n' };
            string[] words, fmt;
            int nlines = 0, nparam;

            fmt = new String[3];
            nlines = 0;
            for (int i = 0; i < programLines.Count(); i++ )
            {
                line = programLines[i];
                words = line.Split(separadores);
                nlines++;
                nparam = 0;
                fmt[0] = fmt[1] = fmt[2] = "";
                foreach (string s in words)
                {
                    if (s.Length > 0)
                    {
                        if (nparam > 0 && onlyOne(fmt[nparam - 1], s))
                            fmt[nparam - 1] = fmt[nparam - 1] + s;
                        else
                        {
                            if (nparam < 3)
                                fmt[nparam] = s;
                            nparam++;
                        }
                    }
                }
                if (nparam > 3)
                    showError("Error de sintaxis: Demasiados argumentos en la linea " + nlines);
                else if (nparam == 1 && !fmt[0].Equals("RSUB"))
                    showError("Error de sintaxis: Muy pocos argumentos en la linea " + nlines);
                else if (nparam > 0)
                    processLine(fmt, nparam, nlines);
            }
            if (bandFinal == false)
                showError("Error de sintaxis: Directiva END no declarada");
            if (Nerror == 0)
                showError("El archivo se analizo correctamente y no se encontro ningun error");
            return Nerror;
        }

        /*Funcion:
                Elimina los espacios en blanco en el operando
         Parametros:
                @s      parte inicial del operando
                @w      parte final del operando
         Regresa:
                true    si ambas partes pertenecen al mismo operando*/
        public bool onlyOne(String s, String w)
        {
            if (s[s.Length - 1] == ',' || s[s.Length - 1] == '\'' || w[0] == '\'' || w[0] == ',' ||
                w == "H" || w == "h" || w == "X" || s == "X" || s == "C")
                return true;
            return false;
        }

        /*Funcion:
                Mostrar el error y agregarlo a la lista de errores
         Parametros:
                @s      error*/
        public void showError(String s)
        {
            Nerror++;
            bool tr = System.Text.RegularExpressions.Regex.IsMatch(s, @"\d\Z");
            System.Console.WriteLine(s + '\n');
            errores.Add(s);
        }

        /*Funcion:
                Realizar el analisis lexico y sintactico de una linea del archivo
         Parametros:
                @s      Parametros de la instruccion
                @nargs  Numero de parametros
                @nl     Numero de linea actual
         Regresa:
                true    si no hubo errores
                false   si hubo errores o encontro la directiva START/END*/
        public bool processLine(String[] s, int nargs, int nl)
        {
            if (validaCab(s, nargs, nl))
            {
                if (validaFin(s, nargs, nl))
                {
                    if (nargs == 3)
                        return ordenEtq(s, nl);
                    else
                        return orden(s[0], s[1], nl);
                }
            }
            return false;
        }

        /*Funcion:
                Validar que aparezca una sola vez la directiva START y sea la primer instruccion
         Parametros:
                @s      Linea a analizar separada en parametros
                @nargs  Numero de parametros
                @nl     Numero de linea actual
         Regresa:
                true    si esta linea es la directiva START*/
        public bool validaCab(String[] s, int nargs, int nl)
        {
            if (bandInicio == false && s[1].Equals("START") == true && validaName(s[0]) && isNumber(s[2]))
            {
                bandInicio = true;
                return false;//ya no hay nada que analizar
            }
            else if (bandInicio == false && Nerror == 0)
            {
                showError("Error de sintaxis: Directiva START no declarada en la linea " + nl);
                return false;
            }
            else if (s[0].Equals("START") == false && s[1].Equals("START") == false)
                return true;
            else if (bandInicio == true && (s[0].Equals("START") || s[1].Equals("START")))
            {
                showError("Error de sintaxis: Doble directiva START en la linea " + nl);
                return false;
            }
            return true;
        }

        /*Funcion:
                Validar que aparezca una sola vez la directiva END y sea la ultima instruccion
         Parametros:
                @s      Linea a analizar separada en parametros
                @nargs  Numero de parametros
                @nl     Numero de linea actual
         Regresa:
                true    si esta linea es la directiva END*/
        public bool validaFin(String[] s, int nargs, int nl)
        {
            if (bandFinal)
            {
                showError("Error de sintaxis: No se esperaba ninguna instruccion despues de la directiva END en la linea " + nl);
                return false;
            }
            else if (s[0].Equals("END") == false && s[1].Equals("END") == false)
                return true;
            else if (bandFinal == false && s[0].Equals("END") == true && (nargs == 1 || (nargs == 2 && validaName(s[1]))))
            {
                bandFinal = true;
                return false;//ya no hay nada que analizar
            }
            return true;
        }

        /*Funcion:
                Agregar la etiqueta a TABSIM y llamar a orden
         Parametros:
                @s      linea con los parametros separados
                @nl     Numero de linea actual
         Regresa:
                true    si no se encontro ningun error*/
        public bool ordenEtq(String[] s, int nl)
        {
            if (!isToken(s[0]))
            {
                if (validaEtq(s[0]))
                    return orden(s[1], s[2], nl);
                else
                    showError("Error de sintaxis: Simbolo duplicado en la linea " + nl);
            }
            else
                showError("Error de sintaxis: Etiqueta no valida en la linea " + nl);
            return false;
        }

        /*Funcion:
                Determinar cual es la instruccion actual para hacer el analisis lexico/sintactico
         Parametros:
                @inst       instruccion
                @op         operando
                @nl         Numero de linea actual
         Regresa:
                true        sino encontro ningun error*/
        public bool orden(String inst, String op, int nl)
        {
            if (isToken(inst))
            {
                if (isToken(op))
                {
                    showError("Error de sintaxis: Operando invalido " + nl);
                    return false;
                }
                else if (inst.Equals("BYTE"))
                    return checaBYTE(op, nl);
                else if (inst.Equals("RSUB"))
                    return checaRSUB(op, nl);
                else
                    return checaInst(inst, op, nl);
            }
            else
            {
                showError("Error de sintaxis: Instruccion no valida en la linea " + nl);
                return false;
            }
            return false;
        }

        /*Funcion:
                Realizar el analisis sintactico de la directiva BYTE
         Parametros:
                @op     operando
                @nl     numero de linea actual
         Regresa:
                true    sino hay errores sintacticos*/
        public bool checaBYTE(String op, int nl)
        {
            if (op.Length < 4 || (op[0] != 'X' && op[0] != 'C') || op[1] != '\'' || op[op.Length - 1] != '\'')
            {
                showError("Error de sintaxis: Formato incorrecto para BYTE en la linea " + nl);
                return false;
            }
            return true;
        }

        /*Funcion:
                Realizar el analisis sintactico de la directiva RSUB
         Parametros:
                @op     operando
                @nl     numero de linea actual
         Regresa:
                true    sino hay errores sintacticos*/
        public bool checaRSUB(String op, int nl)
        {
            if (op.Length > 0)
            {
                showError("Error de sintaxis: Formato incorrecto para RSUB en la linea " + nl);
                return false;
            }
            else
                return true;
        }

        /*Funcion:
                Realizar el analisis sintactico del resto de las instrucciones/directivas
         Parametros:
                @inst   instruccion
                @op     operando
                @nl     numero de linea actual
         Regresa:
                true    sino hay errores sintacticos*/
        public bool checaInst(String inst, String op, int nl)
        {
            if (inst == "START" || inst == "BYTE" || inst == "WORD" || inst == "RESB" || inst == "RESW")
                return isNumber(op);
            else
                return validaName(op);
        }

        /*Funcion:
                Validar el nombre del archivo
         Parametros:
                @s      nombre del archivo
         Regresa:
                true    si el nombre es una cadena valida*/
        public bool validaName(String s)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(s, @"\A\b_?([a-zA-Z])+\b\Z");
        }

        /*Funcion:
                Validar que la etiqueta no esta duplicada e insertarla en TABSIM
         Parametros:
                @s      etiqueta
         Regresa:
                true    si se inserto la etiqueta en TABSIM
                false   si esta duplicada                   */
        public bool validaEtq(String s)
        {
            CSimbolo tag = new CSimbolo(s);

            if (validaName(s))
            {
                if (TABSIM.Contains(new CSimbolo(s)))
                    return false;
                else
                    TABSIM.Add(tag);
                return true;
            }
            return false;
        }

        /*Funcion:
                Validar que @s es un numero*/
        public bool isNumber(String s)
        {
            if (s.Length > 0 && (isDecimal(s) || isHexa(s)))
                return true;
            return false;
        }

        /*Funcion:
                Validar que @s es un numero decimal*/
        public bool isDecimal(String s)
        {
            int n;
            if (int.TryParse(s, out n))
                return true;
            else
                return false;
        }

        /*Funcion:
                Validar que @s es un numero hexadecimal*/
        public bool isHexa(String s)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(s, @"\A\b([0-9a-fA-F]+)(h|H)\b\Z");
        }

        /*Funcion:
                Validar que @s es un token (Analisis lexico)*/
        public bool isToken(String s)
        {
            String[] Token ={"ADD","AND","COMP","DIV","J","JEQ","JGT","JLT","JSUB","LDA","LDCH","LDL","LDX",
                            "MUL","OR","RD","RSUB","STA","STCH","STL","STSW","STX","SUB","TD","TIX","WD",
                            "START","END","BYTE","WORD","RESB","RESW"};
            if (Token.Contains(s))
                return true;
            else
                return false;
        }

        /*Funcion:
                Crear el archivo de errores*/
        internal void escribeErrores()
        {
            File.WriteAllLines(nameArch + "_log.txt", errores);
        }

        internal string getErrors()
        {
            string errorLine = "";
            foreach(var item in errores)
            {
                errorLine += item;
                errorLine += "\r\n";
            }
            return errorLine;
        }
    }
}
