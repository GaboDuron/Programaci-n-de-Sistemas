﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProyectoPS
{
    public partial class Form1 : Form
    {
        private bool modificado = false;
        public string path = "";

        public Form1()
        {
            InitializeComponent();
            bloqueaBut();
        }

        private void bloqueaBut()
        {
            guardarToolStripMenuItem.Enabled = false;
            cerrarToolStripMenuItem.Enabled = false;
            analizarToolStripMenuItem.Enabled = false;
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.CheckFileExists = true;
            dlg.CheckPathExists = true;
            dlg.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";

            DialogResult res = dlg.ShowDialog();
            if(res == DialogResult.OK)
            {
                path = dlg.FileName;
                editorText.Text = File.ReadAllText(dlg.FileName);
                if(modificado)
                {
                    guardarToolStripMenuItem.Enabled = true;
                }
                cerrarToolStripMenuItem.Enabled = true;
                analizarToolStripMenuItem.Enabled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            modificado = true;
            guardarToolStripMenuItem.Enabled = true;
            cerrarToolStripMenuItem.Enabled = true;
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (path != "")
            {
                File.WriteAllText(path, editorText.Text);
            }
            else
            {
                SaveFileDialog dlg = new SaveFileDialog();
                DialogResult res = dlg.ShowDialog();
                if(res == DialogResult.OK)
                {
                    File.WriteAllText(dlg.FileName, editorText.Text);
                }
            }
        }

        private void cerrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorText.Text = "";
            path = "";
            guardarToolStripMenuItem.Enabled = false;
            analizarToolStripMenuItem.Enabled = false;
            cerrarToolStripMenuItem.Enabled = false;
        }

        private void analizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] sep = {"\n"};
            string[] codeLines = editorText.Text.Split(sep,StringSplitOptions.None).ToArray();
            if (codeLines.Contains(""))
            {
                DialogResult res;
                res = MessageBox.Show("El Codigo Fuente tiene lineas vacias. ¿Desea eliminarlas?", "Lineas de codigo vacias", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
                if (res == DialogResult.Yes)
                {
                    codeLines = editorText.Text.Split(sep, StringSplitOptions.RemoveEmptyEntries);
                    editorText.Text = "";
                    foreach (var s in codeLines)
                    {
                        editorText.Text += s;
                        editorText.Text += "\n";
                    }
                    CAnalizador analizador = new CAnalizador(codeLines);
                    analizador.validaSintaxis();
                    textBox2.Text = analizador.getErrors();
                }
                else
                {
                    MessageBox.Show("Elimine las lineas de codigo vacias antes de continuar", "Codigo fuente defectuoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                CAnalizador analizador = new CAnalizador(codeLines);
                analizador.validaSintaxis();
                textBox2.Text = analizador.getErrors();
            }
        }
    }
}
